import javax.crypto.spec.PSource;
import java.io.*;
import java.net.Socket;
import java.util.Scanner;

public class CAhorcado {

    public static void main (String[] args){

        final String IP = "localhost";
        final int PUERTO = 25001;

        try {
            Socket cl = new Socket(IP, PUERTO);
            System.out.println("Conexion con servidor establecida.. recibiendo datos");

            InputStream is = cl.getInputStream(); //Asociamos el stream con el cliente
            InputStreamReader isr = new InputStreamReader(is);
            BufferedReader br = new BufferedReader(isr); //El BufferedReader se usa para leer del cliente al servidor.

            OutputStream os = cl.getOutputStream(); //Asociamos el stream con el cliente
            OutputStreamWriter osr = new OutputStreamWriter(os);
            BufferedWriter bw = new BufferedWriter(osr); //El BufferedWriter se usa para escribir del servidor al cliente.

            //final String FIN = "FIN";
            String palabraEnElMomento = "";
            Scanner sc = new Scanner(System.in);

            System.out.println("Escoge la dificultad del ahorcado (easy) (medium) (hard):");
            String dificultad = sc.nextLine(); //Recogemos la dificultar del usuario
            bw.write(dificultad); //Le mandamos la dificultad al servidor
            bw.newLine();
            bw.flush();

            while(!palabraEnElMomento.equals("-1")) {

                palabraEnElMomento = br.readLine(); //Recibimos la palabra aleatoria del servidor
                if(!palabraEnElMomento.equals("-1")){ // Si recibimos -1 significa que ya adivino la palabra
                    System.out.println("Ok, se ha asignado una palabra, intenta adivinarla:");
                    System.out.println("");
                    System.out.println(palabraEnElMomento);
                    System.out.println("");
                    System.out.println("Escribe una nueva letra: ");
                    String letra;
                    do{
                        letra = sc.nextLine(); //Recogemos la letra del usuario
                        if(letra.length() != 1){
                            System.out.println("Porfavor solo ingresa 1 caracter");
                        }
                    } while(letra.length() != 1);

                    bw.write(letra); //Enviamos la letra
                    bw.newLine();
                    bw.flush();
                }
            } //FIN WHILE
            palabraEnElMomento = br.readLine();
            System.out.println("Felicidades! has adivinado la palabra: " + palabraEnElMomento);
        } catch (IOException e) {
            e.printStackTrace();
        }


    }
}

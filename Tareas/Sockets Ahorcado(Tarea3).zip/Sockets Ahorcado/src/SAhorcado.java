import java.io.*;
import java.net.ServerSocket;
import java.net.Socket;

public class SAhorcado {

    public static void main (String[] args){
        final int port = 25001; //Puerto de nuestro Servidor ( puede ser del 1 al 2^16)

        String[] easy = { "foco", "palo", "domo", "chuz", "chia", "bloc",
                "iman", "buho", "boca", "plato", "goma", "letra", "cuadro",
                "mouse", "lentes", "caja", "vaso", "boya", "dado", "gafas",
                "jabon", "padre", "tabla", "mafia", "jaiba"};
        String[] medium = { "elevador", "refrigerador", "telescopio", "computadora", "pulsera", "celular",
                "calculadora", "ventilador", "teclado", "procesador", "sacapuntas", "credencial", "monitor",
                "tijeras", "destornillador", "engrapadora", "librero", "impresora", "playera", "escritorio",
                "maceta", "azulejo", "bombilla", "diploma", "carpeta"};
        String[] hard = { "juan corre todos los dias", "maría se peina muy temprano",
                "vengo cansado", "nosotros queremos regresar", "ellos trajeron dulces",
                "mi hermana corto flores para mi mama", "mi computadora es muy lenta",
                "las pilas tienen mucha energia", "mi telefono es viejo", "maria baila muy bien"};


        try {
            ServerSocket servidor = new ServerSocket(port); // Escuchamos el servidor en el puerto
            servidor.setReuseAddress(true); //Esto es para que no se congele 15 segundos algo asi xd
            System.out.println("Servidor Iniciado con exito en el puerto: " + servidor.getLocalPort());

            for(;;) {
                Socket cliente = servidor.accept(); // Esperamos a que algun cliente de conecte al servidor.
                System.out.println("Un cliente se ha conectado.");

                /* Para leer en el socket cliente */
                InputStream is = cliente.getInputStream(); //Asociamos el stream con el cliente
                InputStreamReader isr = new InputStreamReader(is);
                BufferedReader br = new BufferedReader(isr); //El BufferedReader se usa para leer del cliente al servidor.

                /* Para escribir en el socket cliente */
                OutputStream os = cliente.getOutputStream(); //Asociamos el stream con el cliente
                OutputStreamWriter osr = new OutputStreamWriter(os);
                BufferedWriter bw = new BufferedWriter(osr); //El BufferedWriter se usa para escribir del servidor al cliente.

                String dificultad = br.readLine(); //Esperamos a que el usuario nos diga la dificultad
                String palabra;

                if(dificultad.equals("easy")){ //Dependiendo la dificultad le establecemos una palabra
                    palabra = easy[ (int)((Math.random()) * (25)) ];
                } else if( dificultad.equals("medium")){
                    palabra = medium[ (int)((Math.random()) * (25)) ];
                } else if(dificultad.equals("hard")){
                    palabra = hard[ (int)((Math.random()) * (10)) ];
                } else{
                    palabra = easy[ (int)((Math.random()) * (25)) ];
                }

                String palabraEnElMomento = "";
                for(int i=0;i<palabra.length();i++){ //Agregamos n guiones bajos
                    if(dificultad.equals("hard") && palabra.charAt(i) == ' ' ){
                        palabraEnElMomento += " ";
                    } else{
                        palabraEnElMomento += "_";
                    }
                }

                String letra;

                do{
                    bw.write(palabraEnElMomento); //Le enviamos al cliente el progreso de la palabra
                    bw.newLine(); //Retorno de carro
                    bw.flush(); //Para estar seguro que le llego al cliente

                    letra = br.readLine(); //Leemos la letra que nos envia el cliente

                    //palabraEnElMomento
                    palabraEnElMomento = checarPalabra(palabra, palabraEnElMomento, letra.charAt(0));
                }while(!palabraEnElMomento.equals(palabra)); //Se rompe el ciclo cuando sean iguales

                bw.write("-1");
                bw.newLine(); //Retorno de carro
                bw.flush(); //Para estar seguro que le llego al cliente

                bw.write(palabra);
                bw.newLine(); //Retorno de carro
                bw.flush(); //Para estar seguro que le llego al cliente
            }

        } catch (IOException e) {
            e.printStackTrace();
        }


    }//FIN MAIN

    static String checarPalabra(String palabra, String palabraEnElMomento, char letra){
        String resultado = "";
        for(int i=0; i<palabra.length() ;i++){
            if(palabra.charAt(i) == letra || palabra.charAt(i) == palabraEnElMomento.charAt(i)){
                resultado += palabra.charAt(i);
            } else{
                resultado += "_";
            }
        }
        return resultado;
    }

}//FIN DE LA CLASE

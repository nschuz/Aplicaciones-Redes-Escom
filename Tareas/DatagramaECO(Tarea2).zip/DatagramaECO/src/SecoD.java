import java.net.*;
import java.io.*;
/**
 *
 * @author axele
 */
public class SecoD {
    public static void main(String[] args){
      try{  
          int pto=1234;
          String msj="";
          DatagramSocket s = new DatagramSocket(pto);
          s.setReuseAddress(true);
          s.setBroadcast(true);
          System.out.println("Servidor iniciado... esperando datagramas..");
          for(;;){
              DatagramPacket p = new DatagramPacket(new byte[100],100);
              s.receive(p);
              System.out.println("Prueba");
              DataInputStream dis = new DataInputStream(new ByteArrayInputStream(p.getData()));
              int n = dis.readInt();
              int tam = dis.readInt();
              byte[] b = new byte[tam];
              int x = dis.read(b);
              String cadena = new String(b);
              System.out.println("Paquete: "+ n+ " con datos: "+cadena);
              dis.close();

              //byte[] b = new byte[65535];
              //msj = new String(p.getData(),0,p.getLength());
              //System.out.println("Se ha recibido datagrama desde "+p.getAddress()+":"+p.getPort()+" con el mensaje:"+msj);
              //ByteArrayOutputStream baos = new ByteArrayOutputStream();
              //DataOutputStream dos = new DataOutputStream(baos);
              s.send(p);
          }//for
          
      }catch(Exception e){
          e.printStackTrace();
      }//catch
        
    }//main
}
